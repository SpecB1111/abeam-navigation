import Foundation

public struct GeoPoint: Codable, Equatable {
    public let lat: Double
    public let lon: Double
    public init(_ lat: Double, _ lon: Double) { self.lat = lat; self.lon = lon }
    public var valid: Bool { lat.isFinite && lon.isFinite && abs(lat) <= 90 && abs(lon) <= 180 }
    public func distance(to other: GeoPoint) -> Double {
        let r = Double.pi / 180
        let a = pow(sin((other.lat - lat) * r / 2), 2) + cos(lat * r) * cos(other.lat * r) * pow(sin((other.lon - lon) * r / 2), 2)
        return 6_371_000 * 2 * atan2(sqrt(max(0, a)), sqrt(max(0, 1 - a)))
    }
}

public struct RouteMatch {
    public let along: Double
    public let away: Double
    public let segment: Int
}

public struct RouteGeometry {
    public let points: [GeoPoint]
    public let cumulative: [Double]
    public var length: Double { cumulative.last ?? 0 }
    public init(_ points: [GeoPoint]) {
        self.points = points.filter(\.valid)
        var sums = [Double](); var distance = 0.0
        for i in self.points.indices {
            if i > 0 { distance += self.points[i - 1].distance(to: self.points[i]) }
            sums.append(distance)
        }
        cumulative = sums
    }
    public func match(_ p: GeoPoint, previous: Double? = nil, course: Double? = nil, window: Double = 600) -> RouteMatch? {
        guard p.valid, points.count > 1 else { return nil }
        let scale = max(0.0001, cos(p.lat * .pi / 180))
        var best: RouteMatch?; var score = Double.infinity
        for i in 0..<(points.count - 1) {
            if let previous, cumulative[i + 1] < previous - 120 || cumulative[i] > previous + window { continue }
            let a = points[i]; let b = points[i + 1]
            let ax = (a.lon - p.lon) * 111_195 * scale; let ay = (a.lat - p.lat) * 111_195
            let bx = (b.lon - p.lon) * 111_195 * scale; let by = (b.lat - p.lat) * 111_195
            let dx = bx - ax; let dy = by - ay; let squared = dx * dx + dy * dy
            guard squared > 0.01 else { continue }
            let t = min(1, max(0, -(ax * dx + ay * dy) / squared))
            let away = hypot(ax + t * dx, ay + t * dy)
            let along = cumulative[i] + t * (cumulative[i + 1] - cumulative[i])
            var penalty = 0.0
            if let course, course >= 0, course < 360 {
                let bearing = (atan2(dx, dy) * 180 / .pi + 360).truncatingRemainder(dividingBy: 360)
                let angle = abs((bearing - course + 540).truncatingRemainder(dividingBy: 360) - 180)
                penalty += angle > 100 ? 45 : 0
            }
            if let previous { penalty += max(0, previous - along) * 0.15 }
            if away + penalty < score {
                score = away + penalty; best = RouteMatch(along: along, away: away, segment: i)
            }
        }
        return best
    }
}

public struct PositionFix {
    public let point: GeoPoint
    public let time: Date
    public let accuracy: Double
    public let speed: Double
    public init(point: GeoPoint, time: Date, accuracy: Double, speed: Double) {
        self.point = point; self.time = time; self.accuracy = accuracy; self.speed = speed
    }
    public func usable(at now: Date) -> Bool {
        point.valid && accuracy.isFinite && accuracy >= 0 && accuracy <= 40 && time.timeIntervalSince(now) <= 2 && now.timeIntervalSince(time) <= 8
    }
}

// Verified, direction-specific zone geometry is required. Opening the app inside
// a zone cannot establish its entry time; never display a fabricated average.
public struct AverageZoneTracker {
    public private(set) var entryTime: Date?
    public private(set) var metres = 0.0
    public private(set) var valid = false
    private var last: PositionFix?
    public init() {}
    public mutating func enter(_ fix: PositionFix, now: Date) {
        reset()
        guard fix.usable(at: now) else { return }
        entryTime = fix.time; last = fix; valid = true
    }
    public mutating func add(_ fix: PositionFix, now: Date) {
        guard valid, let previous = last else { return }
        let dt = fix.time.timeIntervalSince(previous.time)
        guard fix.usable(at: now), dt > 0, dt <= 8 else { reset(); return }
        let distance = previous.point.distance(to: fix.point)
        guard distance / dt <= 70 else { reset(); return }
        metres += distance; last = fix
    }
    public func speedKPH(at now: Date) -> Double? {
        guard valid, let entryTime, let last, last.usable(at: now) else { return nil }
        let seconds = last.time.timeIntervalSince(entryTime)
        guard seconds >= 10 else { return nil }
        return metres / seconds * 3.6
    }
    public mutating func reset() { entryTime = nil; metres = 0; valid = false; last = nil }
}

public enum HazardClassifier {
    public static func classify(category: String, roadClosed: Bool) -> String {
        if roadClosed { return "Road closure" }
        let value = category.uppercased()
        if value.contains("ROADWORK") { return "Roadworks" }
        if value.contains("CRASH") { return "Crash" }
        return "Road hazard"
    }
}
