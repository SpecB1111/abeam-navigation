import XCTest
@testable import AbeamCore

final class NavigationTests: XCTestCase {
    func testDistanceMetres() {
        XCTAssertEqual(GeoPoint(0, 0).distance(to: GeoPoint(0, 0.01)), 1111.95, accuracy: 1)
    }
    func testRouteProjectionAndLateralDistance() {
        let route = RouteGeometry([GeoPoint(0, 0), GeoPoint(0, 0.01)])
        let match = route.match(GeoPoint(0.001, 0.005))!
        XCTAssertEqual(match.along, 555.98, accuracy: 1)
        XCTAssertEqual(match.away, 111.195, accuracy: 1)
    }
    func testNoJumpToLaterCrossing() {
        let route = RouteGeometry([GeoPoint(0, 0), GeoPoint(0, 0.01), GeoPoint(0.01, 0.01), GeoPoint(0.01, 0), GeoPoint(0, 0)])
        let match = route.match(GeoPoint(0, 0.00001), previous: 10, course: 90)!
        XCTAssertLessThan(match.along, 30)
    }
    func testDegenerateAndInvalidGeometry() {
        XCTAssertNil(RouteGeometry([GeoPoint(0, 0)]).match(GeoPoint(0, 0)))
        XCTAssertNil(RouteGeometry([GeoPoint(0, 0), GeoPoint(0, 0)]).match(GeoPoint(0, 0)))
        XCTAssertNil(RouteGeometry([GeoPoint(0, 0), GeoPoint(1, 1)]).match(GeoPoint(.nan, 0)))
    }
    func testStaleAndInaccurateFixesRejected() {
        let now = Date()
        XCTAssertFalse(PositionFix(point: GeoPoint(0, 0), time: now.addingTimeInterval(-9), accuracy: 3, speed: 0).usable(at: now))
        XCTAssertFalse(PositionFix(point: GeoPoint(0, 0), time: now, accuracy: 41, speed: 0).usable(at: now))
        XCTAssertFalse(PositionFix(point: GeoPoint(0, 0), time: now.addingTimeInterval(3), accuracy: 3, speed: 0).usable(at: now))
    }
    func testAverageNeedsObservedEntryAndEnoughTime() {
        var tracker = AverageZoneTracker(); let time = Date()
        let fix = PositionFix(point: GeoPoint(0, 0), time: time, accuracy: 3, speed: 10)
        tracker.add(fix, now: time); XCTAssertNil(tracker.speedKPH(at: time))
        tracker.enter(fix, now: time); XCTAssertNil(tracker.speedKPH(at: time))
        for i in 1...12 {
            let next = time.addingTimeInterval(Double(i))
            tracker.add(PositionFix(point: GeoPoint(0, Double(i) * 0.00009), time: next, accuracy: 3, speed: 10), now: next)
        }
        XCTAssertEqual(tracker.speedKPH(at: time.addingTimeInterval(12))!, 36.03, accuracy: 0.1)
    }
    func testAverageInvalidatesOnGapOrTeleport() {
        let time = Date(); var tracker = AverageZoneTracker()
        tracker.enter(PositionFix(point: GeoPoint(0, 0), time: time, accuracy: 3, speed: 0), now: time)
        let next = time.addingTimeInterval(9)
        tracker.add(PositionFix(point: GeoPoint(0, 0.001), time: next, accuracy: 3, speed: 0), now: next)
        XCTAssertFalse(tracker.valid)
        tracker.enter(PositionFix(point: GeoPoint(0, 0), time: time, accuracy: 3, speed: 0), now: time)
        tracker.add(PositionFix(point: GeoPoint(1, 1), time: time.addingTimeInterval(1), accuracy: 3, speed: 0), now: time.addingTimeInterval(1))
        XCTAssertFalse(tracker.valid)
    }
    func testEmergencyRoadworkAndClosureClassification() {
        XCTAssertEqual(HazardClassifier.classify(category: "EMERGENCY ROADWORK", roadClosed: false), "Roadworks")
        XCTAssertEqual(HazardClassifier.classify(category: "CRASH", roadClosed: true), "Road closure")
        XCTAssertEqual(HazardClassifier.classify(category: "POLICE OPERATION", roadClosed: false), "Road hazard")
    }
}
