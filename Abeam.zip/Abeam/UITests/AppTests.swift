import XCTest

final class AppTests: XCTestCase {
    func testLaunchSettingsAndSavedPlaces() {
        let app = XCUIApplication()
        app.launchArguments = ["-navigationNoticeAccepted", "YES"]
        addUIInterruptionMonitor(withDescription: "Location permission") { alert in
            let allow = alert.buttons["Allow While Using App"]
            if allow.exists { allow.tap(); return true }
            return false
        }
        app.launch()
        XCTAssertTrue(app.textFields["Where are we heading?"].waitForExistence(timeout: 30))
        app.tap()
        let initial = XCTAttachment(screenshot: app.screenshot())
        initial.name = "Abeam iPhone map"; initial.lifetime = .keepAlways; add(initial)
        app.buttons["Settings"].tap()
        XCTAssertTrue(app.navigationBars["Make it yours"].waitForExistence(timeout: 10))
        let voice = app.switches["Spoken directions and alerts"]
        XCTAssertTrue(voice.exists)
        let before = voice.value as? String
        voice.tap()
        let after = voice.value as? String
        XCTAssertNotEqual(before, after)
        app.buttons["Done"].tap()
        app.terminate(); app.launch()
        XCTAssertTrue(app.buttons["Settings"].waitForExistence(timeout: 20))
        app.buttons["Settings"].tap()
        XCTAssertEqual(app.switches["Spoken directions and alerts"].value as? String, after)
        app.buttons["Done"].tap()
        app.buttons["Saved"].tap()
        XCTAssertTrue(app.navigationBars["Saved places"].waitForExistence(timeout: 10))
        app.buttons["Done"].tap()
        XCTAssertTrue(app.textFields["Where are we heading?"].waitForExistence(timeout: 10))
    }
}
