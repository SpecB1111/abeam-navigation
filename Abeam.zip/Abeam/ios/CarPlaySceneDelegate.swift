import CarPlay
import MapKit
import Combine

// Restricted to the separately signed CarPlay target. The AltStore phone target
// deliberately does not claim the Apple-controlled navigation entitlement.
@MainActor
final class CarPlaySceneDelegate: UIResponder, CPTemplateApplicationSceneDelegate, CPMapTemplateDelegate, MKMapViewDelegate {
    private var mapView: MKMapView?
    private var interface: CPInterfaceController?
    private var template: CPMapTemplate?
    private var trip: CPTrip?
    private var session: CPNavigationSession?
    private var refresh: AnyCancellable?
    private var shownRoute: MKRoute?
    private var maneuverID: Int?
    private var cpManeuver: CPManeuver?

    func templateApplicationScene(_ scene: CPTemplateApplicationScene, didConnect controller: CPInterfaceController, to window: CPWindow) {
        interface = controller
        let viewController = UIViewController(); let map = MKMapView(frame: window.bounds)
        map.autoresizingMask = [.flexibleWidth, .flexibleHeight]; map.delegate = self
        map.showsUserLocation = true; map.showsTraffic = true
        map.setRegion(.init(center: DriveModel.sydney, span: .init(latitudeDelta: 0.08, longitudeDelta: 0.08)), animated: false)
        viewController.view = map; window.rootViewController = viewController; mapView = map
        let template = CPMapTemplate(); template.mapDelegate = self; self.template = template
        let recenter = CPMapButton { [weak map] _ in map?.setUserTrackingMode(.followWithHeading, animated: true) }
        recenter.image = UIImage(systemName: "location.fill")
        let mute = CPMapButton { _ in DriveModel.shared.voice.toggle() }; mute.image = UIImage(systemName: "speaker.wave.2.fill")
        template.mapButtons = [recenter, mute]
        let saved = CPBarButton(type: .text) { [weak self] _ in self?.showSaved() }; saved.title = "Saved"
        let reports = CPBarButton(type: .text) { [weak self] _ in self?.showReports() }; reports.title = "Report"
        template.leadingNavigationBarButtons = [saved]; template.trailingNavigationBarButtons = [reports]
        controller.setRootTemplate(template, animated: false) { _, error in if let error { DriveModel.shared.message = error.localizedDescription } }
        refresh = Timer.publish(every: 1, on: .main, in: .common).autoconnect().sink { [weak self] _ in self?.sync() }
        DriveModel.shared.requestLocation()
    }
    private func sync() {
        let model = DriveModel.shared
        if shownRoute !== model.route {
            session?.cancelTrip(); session = nil; cpManeuver = nil; maneuverID = nil
            shownRoute = model.route; mapView?.removeOverlays(mapView?.overlays ?? [])
            template?.hideTripPreviews(); trip = nil
            if let route = model.route, let destination = model.destination, let location = model.usableLocation {
                mapView?.addOverlay(route.polyline)
                let choice = CPRouteChoice(summaryVariants: ["\(Int(ceil(route.expectedTravelTime / 60))) min"], additionalInformationVariants: [DriveModel.distance(route.distance)], selectionSummaryVariants: [route.name])
                let origin = MKMapItem(placemark: MKPlacemark(coordinate: location.coordinate))
                let nextTrip = CPTrip(origin: origin, destination: destination, routeChoices: [choice]); trip = nextTrip
                if !model.navigating {
                    template?.showTripPreviews([nextTrip], textConfiguration: nil)
                    mapView?.setVisibleMapRect(route.polyline.boundingMapRect, edgePadding: .init(top: 90, left: 200, bottom: 80, right: 80), animated: true)
                }
            }
        }
        if model.navigating, let trip, let template {
            if session == nil { template.hideTripPreviews(); session = template.startNavigationSession(for: trip); mapView?.setUserTrackingMode(.followWithHeading, animated: true) }
            let id = model.gpsReady ? model.currentManeuver?.id ?? -1 : -2
            if maneuverID != id {
                maneuverID = id; let maneuver = CPManeuver()
                maneuver.instructionVariants = [model.guidance]
                maneuver.initialTravelEstimates = CPTravelEstimates(distanceRemaining: Measurement(value: model.maneuverDistance, unit: .meters), timeRemaining: max(0, model.maneuverDistance / 12))
                cpManeuver = maneuver; session?.upcomingManeuvers = [maneuver]
            }
            if let cpManeuver, model.gpsReady {
                session?.updateEstimates(CPTravelEstimates(distanceRemaining: Measurement(value: model.maneuverDistance, unit: .meters), timeRemaining: max(0, model.maneuverDistance / 12)), for: cpManeuver)
            }
            template.updateEstimates(CPTravelEstimates(distanceRemaining: Measurement(value: model.remainingDistance, unit: .meters), timeRemaining: model.remainingTime), for: trip)
        } else if session != nil { session?.cancelTrip(); session = nil; maneuverID = nil }
    }
    func mapTemplate(_ mapTemplate: CPMapTemplate, startedTrip trip: CPTrip, using routeChoice: CPRouteChoice) { DriveModel.shared.startNavigation(); sync() }
    func mapTemplateDidCancelNavigation(_ mapTemplate: CPMapTemplate) { DriveModel.shared.clearRoute(); session = nil }
    private func showSaved() {
        let model = DriveModel.shared
        let items = model.favourites.map { place -> CPListItem in
            let item = CPListItem(text: place.name, detailText: "Plan route")
            item.handler = { [weak self] _, completion in
                let destination = MKMapItem(placemark: MKPlacemark(coordinate: .init(latitude: place.latitude, longitude: place.longitude))); destination.name = place.name
                Task { await model.plan(to: destination); self?.interface?.popToRootTemplate(animated: true, completion: nil); completion() }
            }; return item
        }
        let list = CPListTemplate(title: "Saved places", sections: [CPListSection(items: items)])
        list.emptyViewTitleVariants = ["Save destinations on your iPhone"]
        interface?.pushTemplate(list, animated: true, completion: nil)
    }
    private func showReports() {
        let items = [AlertKind.police, .mobile, .crash, .hazard, .works].map { kind -> CPListItem in
            let item = CPListItem(text: kind.rawValue, detailText: "Save on this device only", image: UIImage(systemName: kind.symbol))
            item.handler = { [weak self] _, completion in DriveModel.shared.addReport(kind); self?.interface?.popToRootTemplate(animated: true, completion: nil); completion() }
            return item
        }
        interface?.pushTemplate(CPListTemplate(title: "Local observation", sections: [CPListSection(items: items)]), animated: true, completion: nil)
    }
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        guard let line = overlay as? MKPolyline else { return MKOverlayRenderer(overlay: overlay) }
        let renderer = MKPolylineRenderer(polyline: line); renderer.strokeColor = .systemMint; renderer.lineWidth = 7; return renderer
    }
    func templateApplicationScene(_ scene: CPTemplateApplicationScene, didDisconnect controller: CPInterfaceController, from window: CPWindow) {
        refresh = nil; session?.cancelTrip(); session = nil; mapView?.delegate = nil; mapView = nil; interface = nil; template = nil; trip = nil; shownRoute = nil; window.rootViewController = nil
    }
}
