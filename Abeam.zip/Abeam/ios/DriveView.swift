import SwiftUI
import MapKit

struct DriveView: View {
    @EnvironmentObject var model: DriveModel
    @State private var position: MapCameraPosition = .region(.init(center: DriveModel.sydney, span: .init(latitudeDelta: 0.05, longitudeDelta: 0.05)))
    @State private var sheet: Panel?
    @State private var selectedAlert: RoadAlert?
    @Environment(\.accessibilityReduceMotion) private var reducedMotion
    @AppStorage("navigationNoticeAccepted") private var noticeAccepted = false
    private let mint = Color(red: 0.3, green: 0.78, blue: 0.63)
    enum Panel: String, Identifiable { case reports, settings, steps, nearby, saved; var id: String { rawValue } }

    var body: some View {
        Map(position: $position) {
            UserAnnotation()
            if let route = model.route { MapPolyline(route.polyline).stroke(mint, lineWidth: 7) }
            if let destination = model.destination { Marker(destination.name ?? "Destination", coordinate: destination.placemark.coordinate).tint(mint) }
            ForEach(model.visibleAlerts) { alert in
                Annotation(alert.kind.rawValue, coordinate: alert.coordinate) {
                    Button { selectedAlert = alert } label: {
                        Image(systemName: alert.kind.symbol).font(.system(size: 16, weight: .semibold)).foregroundStyle(.black)
                            .padding(11).background(alert.kind == .speed ? Color.orange.opacity(0.9) : mint, in: RoundedRectangle(cornerRadius: 13))
                    }.accessibilityLabel("\(alert.title). Show source and details.")
                }
            }
        }
        .mapStyle(.standard(elevation: .realistic, showsTraffic: true))
        .mapControls { MapCompass(); MapScaleView() }
        .safeAreaInset(edge: .top) { topPanel }
        .safeAreaInset(edge: .bottom) { bottomPanel }
        .overlay(alignment: .trailing) { mapButtons }
        .tint(mint)
        .task { model.requestLocation(); model.refreshTraffic() }
        .onChange(of: model.mapRevision) { _, _ in
            if model.navigating { follow() }
            else if let route = model.route {
                let rect = route.polyline.boundingMapRect
                withAnimation(reducedMotion ? nil : .easeInOut(duration: 0.6)) { position = .rect(rect.insetBy(dx: -max(100, rect.size.width * 0.15), dy: -max(100, rect.size.height * 0.15))) }
            }
        }
        .onChange(of: model.navigating) { _, active in if active { follow() } }
        .sheet(item: $sheet) { panel in
            NavigationStack {
                Group {
                    switch panel {
                    case .reports: reportPanel
                    case .settings: settingsPanel
                    case .steps: stepsPanel
                    case .nearby: nearbyPanel
                    case .saved: savedPanel
                    }
                }.toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { sheet = nil } } }
            }.tint(mint)
        }
        .sheet(item: $selectedAlert) { alert in alertDetail(alert) }
        .alert("Before your first drive", isPresented: Binding(get: { !noticeAccepted }, set: { if !$0 { noticeAccepted = true } })) {
            Button("I understand") { noticeAccepted = true }
        } message: {
            Text("YOUR USE OF THIS REAL TIME ROUTE GUIDANCE APPLICATION IS AT YOUR SOLE RISK. Location data may not be accurate. Always follow actual road signs and conditions. This early build has not been road-tested. Search and routing use Apple services; NSW feeds do not receive your GPS position.")
        }
    }
    private func follow() { position = .userLocation(followsHeading: true, fallback: .automatic) }
    private var topPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            if model.navigating || model.arrived {
                HStack(spacing: 15) {
                    Image(systemName: model.arrived ? "checkmark.circle.fill" : "arrow.triangle.turn.up.right.diamond.fill").font(.system(size: 35)).foregroundStyle(mint)
                    VStack(alignment: .leading, spacing: 5) {
                        if model.gpsReady && !model.arrived { Text(model.distanceText).font(.largeTitle.bold()).monospacedDigit() }
                        Text(model.guidance).font(.headline).fixedSize(horizontal: false, vertical: true)
                    }; Spacer(minLength: 0)
                }
            } else {
                HStack { Label("abeam.", systemImage: "arrow.up.right").font(.title2.bold()); Spacer(); Text(model.gpsReady ? "GPS READY" : "WAITING FOR GPS").font(.caption2.bold()).foregroundStyle(model.gpsReady ? mint : .orange) }
                HStack {
                    Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                    TextField("Where are we heading?", text: $model.query).submitLabel(.search).onSubmit { Task { await model.searchPlaces() } }
                    Button { Task { await model.searchPlaces() } } label: { Image(systemName: "arrow.right.circle.fill").font(.title2) }.accessibilityLabel("Search destinations").disabled(model.query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || model.busy)
                }.padding(13).background(.primary.opacity(0.07), in: RoundedRectangle(cornerRadius: 14))
                if !model.results.isEmpty { searchResults }
            }
            if model.busy { ProgressView("Calculating…").font(.caption) }
        }.padding(18).background(.ultraThickMaterial, in: RoundedRectangle(cornerRadius: 24)).padding(.horizontal, 12).padding(.top, 8)
    }
    private var searchResults: some View {
        ScrollView { VStack(spacing: 0) {
            ForEach(Array(model.results.enumerated()), id: \.offset) { _, item in
                Button { Task { await model.plan(to: item) } } label: {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(item.name ?? "Destination").foregroundStyle(.primary)
                        Text(item.placemark.title ?? "").font(.caption).foregroundStyle(.secondary)
                    }.frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 12)
                }; Divider()
            }
        } }.frame(maxHeight: 210)
    }
    private var mapButtons: some View {
        VStack(spacing: 10) {
            Button { model.requestLocation(); follow() } label: { Image(systemName: "location.fill").frame(width: 46, height: 46) }.accessibilityLabel("Follow my location")
            Button { model.voice.toggle() } label: { Image(systemName: model.voice ? "speaker.wave.2.fill" : "speaker.slash.fill").frame(width: 46, height: 46) }.accessibilityLabel(model.voice ? "Mute directions" : "Enable spoken directions")
            if model.navigating {
                VStack(spacing: 1) { Text(model.speedKPH.map(String.init) ?? "—").font(.title2.bold()).monospacedDigit(); Text("GPS km/h").font(.system(size: 9)) }.frame(width: 60, height: 58)
            } else {
                Button { sheet = .settings } label: { Image(systemName: "slider.horizontal.3").frame(width: 46, height: 46) }.accessibilityLabel("Settings")
            }
        }.background(.ultraThickMaterial, in: RoundedRectangle(cornerRadius: 18)).padding(.trailing, 12)
    }
    private var bottomPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            if let message = model.message {
                HStack(alignment: .top) { Text(message).font(.caption); Spacer(); Button { model.message = nil } label: { Image(systemName: "xmark.circle.fill") }.accessibilityLabel("Dismiss message") }
            }
            if let alert = model.upcomingAlert {
                Button { selectedAlert = alert } label: { Label(alert.title, systemImage: alert.kind.symbol).font(.subheadline.bold()).frame(maxWidth: .infinity, alignment: .leading) }
                Text(alert.source).font(.caption2).foregroundStyle(.secondary)
                Divider()
            }
            if let route = model.route {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(model.arrived ? "Arrived" : "\(Int(ceil((model.navigating ? model.remainingTime : route.expectedTravelTime) / 60))) min").font(.title.bold()).foregroundStyle(mint)
                        Text("\(DriveModel.distance(model.navigating ? model.remainingDistance : route.distance)) · \(model.destination?.name ?? "Destination")").font(.caption)
                        if model.navigating { Text("ETA estimate · updates with route progress").font(.caption2).foregroundStyle(.secondary) }
                    }; Spacer(); Button(model.navigating ? "End" : "Clear") { model.clearRoute() }.buttonStyle(.bordered)
                }
                if !model.navigating && !model.arrived {
                    HStack {
                        Button { model.saveDestination() } label: { Image(systemName: "bookmark") }.accessibilityLabel("Save destination").buttonStyle(.bordered)
                        Button("Steps") { sheet = .steps }.buttonStyle(.bordered)
                        Button("Start drive", systemImage: "arrow.up.right") { model.startNavigation() }.buttonStyle(.borderedProminent).foregroundStyle(.black).disabled(!model.gpsReady || model.busy)
                    }
                }
            } else {
                HStack { Button("Saved", systemImage: "bookmark.fill") { sheet = .saved }; Spacer(); Button("Nearby", systemImage: "exclamationmark.bubble.fill") { sheet = .nearby } }
                Text(model.feedStatus).font(.caption2).foregroundStyle(.secondary)
            }
            HStack {
                Button { sheet = .nearby } label: { Text("\(model.nearby.count) nearby notices").font(.caption) }
                Spacer(); Button { sheet = .reports } label: { Label("Report", systemImage: "plus") }.font(.subheadline.bold())
            }
        }.padding(18).background(.ultraThickMaterial, in: RoundedRectangle(cornerRadius: 24)).padding(12)
    }
    private var reportPanel: some View {
        List {
            Section { Text("Save an observation at your current GPS position. Reports are stored on this phone only. Shared community reports are not connected.").font(.subheadline).foregroundStyle(.secondary) }
            ForEach(AlertKind.allCases.filter { $0 != .average }) { kind in
                Button { model.addReport(kind); sheet = nil } label: { Label(kind.rawValue, systemImage: kind.symbol).padding(.vertical, 7) }.disabled(!model.gpsReady)
            }
        }.navigationTitle("Report a sighting")
    }
    private var settingsPanel: some View {
        Form {
            Section("Your drive") {
                Toggle("Spoken directions and alerts", isOn: $model.voice)
                Picker("Appearance", selection: $model.appearance) { Text("Automatic").tag("system"); Text("Day").tag("light"); Text("Night").tag("dark") }
            }
            Section("Alert categories") {
                ForEach(AlertKind.allCases) { kind in
                    Toggle(kind.rawValue, isOn: Binding(get: { model.enabledKinds.contains(kind) }, set: { on in if on { model.enabledKinds.insert(kind) } else { model.enabledKinds.remove(kind) } }))
                }
            }
            Section("Data coverage") {
                Text(model.feedStatus); if let date = model.feedUpdated { Text("Last fetched \(date.formatted(date: .omitted, time: .shortened))").font(.caption) }
                Button("Refresh road notices") { model.refreshTraffic() }
                Text(model.cameraStatus).font(.caption)
                Text("Police and mobile cameras: your own saved observations only. Waze is not connected. Average-speed zone boundaries and automatic zone measurement are not available. There is no verified road speed-limit database.").font(.caption)
            }
            Section("Sources & privacy") {
                Link("Transport for NSW — live traffic data", destination: URL(string: "https://opendata.transport.nsw.gov.au/dataset/live-traffic-hazards")!)
                Link("© OpenStreetMap contributors — ODbL", destination: URL(string: "https://www.openstreetmap.org/copyright")!)
                Text("Apple provides maps, search, traffic rendering and routes. Your search and route coordinates go to Apple. NSW feed requests contain no GPS coordinates. Saved places and your reports stay on this phone. No analytics or account is required.").font(.caption)
                Text("Background GPS is enabled only during navigation. Abeam is an early build; route instructions and camera data have not been validated on-road.").font(.caption)
            }
        }.navigationTitle("Make it yours")
    }
    private var stepsPanel: some View {
        List {
            if let route = model.route {
                ForEach(Array(route.steps.filter { !$0.instructions.isEmpty }.enumerated()), id: \.offset) { _, step in
                    VStack(alignment: .leading, spacing: 6) { Text(step.instructions); Text(DriveModel.distance(step.distance)).font(.caption).foregroundStyle(.secondary) }
                }
            }
            Button("Open destination in Apple Maps") { model.openAppleMaps() }
        }.navigationTitle("Your route")
    }
    private var nearbyPanel: some View {
        List {
            Section { Text(model.feedStatus).font(.caption); Text("Within 50 km of your position, or Sydney while GPS is unavailable. Notices may be on nearby roads rather than your route.").font(.caption) }
            if model.nearby.isEmpty { Text("No notices available here. This does not establish that roads are clear.") }
            ForEach(model.nearby) { alert in
                NavigationLink { alertContents(alert) } label: {
                    Label { VStack(alignment: .leading, spacing: 4) { Text(alert.title); Text(alert.source).font(.caption).foregroundStyle(.secondary) } } icon: { Image(systemName: alert.kind.symbol) }
                }
            }
        }.navigationTitle("The road ahead").refreshable { model.refreshTraffic() }
    }
    private var savedPanel: some View {
        List {
            if model.favourites.isEmpty { Text("Plan a route, then tap the bookmark to save its destination.") }
            ForEach(model.favourites) { place in
                Button { let item = MKMapItem(placemark: MKPlacemark(coordinate: .init(latitude: place.latitude, longitude: place.longitude))); item.name = place.name; sheet = nil; Task { await model.plan(to: item) } } label: { Label(place.name, systemImage: "bookmark.fill") }
            }.onDelete { model.favourites.remove(atOffsets: $0) }
        }.navigationTitle("Saved places")
    }
    private func alertContents(_ alert: RoadAlert) -> some View {
        List {
            Label(alert.title, systemImage: alert.kind.symbol)
            Text(alert.detail); Text(alert.source).font(.caption)
            Text("Source updated \(alert.observed.formatted(date: .abbreviated, time: .shortened))").font(.caption)
            if alert.isLocal { Button("Delete my report", role: .destructive) { model.removeReport(alert.id); selectedAlert = nil } }
        }.navigationTitle(alert.kind.rawValue)
    }
    private func alertDetail(_ alert: RoadAlert) -> some View {
        NavigationStack { alertContents(alert).toolbar { Button("Done") { selectedAlert = nil } } }.presentationDetents([.medium, .large])
    }
}
