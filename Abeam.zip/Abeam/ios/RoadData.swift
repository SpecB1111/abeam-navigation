import Foundation
import CoreLocation

enum AlertKind: String, CaseIterable, Identifiable, Codable {
    case police = "Police reported", speed = "Speed camera", average = "Average-speed zone"
    case mobile = "Mobile camera", redLight = "Red-light camera"
    case works = "Roadworks", crash = "Crash", closure = "Road closure", hazard = "Road hazard"
    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .police: return "shield.lefthalf.filled"
        case .speed, .mobile, .redLight: return "camera.fill"
        case .average: return "arrow.left.and.right"
        case .works: return "cone.fill"
        case .crash: return "car.side.fill"
        case .closure: return "minus.circle.fill"
        case .hazard: return "exclamationmark.triangle.fill"
        }
    }
}

struct RoadAlert: Identifiable, Codable {
    let id: String
    let kind: AlertKind
    let latitude: Double
    let longitude: Double
    let title: String
    let detail: String
    let source: String
    let observed: Date
    let expires: Date
    let isLocal: Bool
    var coordinate: CLLocationCoordinate2D { .init(latitude: latitude, longitude: longitude) }
    var point: GeoPoint { GeoPoint(latitude, longitude) }
}

struct SavedPlace: Codable, Identifiable {
    var id = UUID()
    let name: String
    let latitude: Double
    let longitude: Double
}

struct CameraBundle: Decodable {
    let retrieved: String
    let cameras: [Camera]
    struct Camera: Decodable {
        let id: String; let lat: Double; let lon: Double; let title: String
        let source: String; let updated: String
    }
    func alerts() -> [RoadAlert] {
        let formatter = ISO8601DateFormatter()
        return cameras.compactMap { camera in
            guard GeoPoint(camera.lat, camera.lon).valid else { return nil }
            return RoadAlert(id: camera.id, kind: .speed, latitude: camera.lat, longitude: camera.lon,
                             title: camera.title, detail: "Mapped camera. Direction, operation and current speed limit are not verified. Snapshot: \(retrieved.prefix(10)).",
                             source: "© OpenStreetMap contributors · ODbL", observed: formatter.date(from: camera.updated) ?? .distantPast,
                             expires: .distantFuture, isLocal: false)
        }
    }
}

enum RoadData {
    static let feeds = ["incident-open", "roadwork-open", "flood-open", "fire-open", "alpine-open", "majorevent-open"]
    static func load(_ name: String) async throws -> [RoadAlert] {
        guard feeds.contains(name), let url = URL(string: "https://data.livetraffic.com/traffic/hazards/\(name).json") else { throw URLError(.badURL) }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 20)
        request.setValue("Abeam/0.2", forHTTPHeaderField: "User-Agent")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
        return try parse(data, feed: name, now: Date())
    }
    static func parse(_ data: Data, feed: String, now: Date) throws -> [RoadAlert] {
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let features = root["features"] as? [[String: Any]] else { throw URLError(.cannotParseResponse) }
        return features.compactMap { item in
            guard let properties = item["properties"] as? [String: Any],
                  let geometry = item["geometry"] as? [String: Any], geometry["type"] as? String == "Point",
                  let coordinates = geometry["coordinates"] as? [Double], coordinates.count >= 2,
                  GeoPoint(coordinates[1], coordinates[0]).valid,
                  properties["ended"] as? Bool != true else { return nil }
            let end = (properties["end"] as? Double).map { Date(timeIntervalSince1970: $0 / 1000) }
            if let end, end < now { return nil }
            let start = (properties["start"] as? Double).map { Date(timeIntervalSince1970: $0 / 1000) }
            let category = properties["mainCategory"] as? String ?? "Road hazard"
            let periods = properties["periods"] as? [[String: Any]] ?? []
            let closed = periods.contains { $0["closureType"] as? String == "ROAD_CLOSURE" }
            let kind = AlertKind(rawValue: HazardClassifier.classify(category: category, roadClosed: closed)) ?? .hazard
            let roads = properties["roads"] as? [[String: Any]] ?? []
            let road = roads.first?["mainStreet"] as? String ?? ""
            let suburb = roads.first?["suburb"] as? String ?? ""
            let advice = ["adviceA", "adviceB", "adviceC"].compactMap { properties[$0] as? String }.filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }.joined(separator: ". ")
            let scheduled = start.map { $0 > now } ?? false
            let title = (scheduled ? "Scheduled: " : "") + (road.isEmpty ? category.capitalized : "\(kind.rawValue) · \(road)")
            let observed = Date(timeIntervalSince1970: (properties["lastUpdated"] as? Double ?? now.timeIntervalSince1970 * 1000) / 1000)
            return RoadAlert(id: "nsw-\(feed)-\(String(describing: item["id"] ?? road))", kind: kind,
                             latitude: coordinates[1], longitude: coordinates[0], title: title,
                             detail: "\(suburb). \(advice) Published notice; roadwork and closure hours may vary. Check signs.",
                             source: "Transport for NSW · Live Traffic NSW", observed: observed,
                             expires: min(end ?? .distantFuture, now.addingTimeInterval(300)), isLocal: false)
        }
    }
}
