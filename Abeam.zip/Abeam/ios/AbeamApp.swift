import SwiftUI

@main
struct AbeamApp: App {
    @StateObject private var model = DriveModel.shared
    var body: some Scene {
        WindowGroup { DriveView().environmentObject(model).preferredColorScheme(model.appearance == "dark" ? .dark : model.appearance == "light" ? .light : nil) }
    }
}
