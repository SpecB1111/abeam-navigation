import Foundation
import MapKit
import CoreLocation
import Combine
import AVFoundation
import UIKit

struct Maneuver: Identifiable {
    let id: Int
    let instruction: String
    let along: Double
    let coordinate: CLLocationCoordinate2D
}

@MainActor
final class DriveModel: NSObject, ObservableObject, CLLocationManagerDelegate {
    static let shared = DriveModel()
    static let sydney = CLLocationCoordinate2D(latitude: -33.884, longitude: 151.215)
    @Published var query = ""
    @Published var results: [MKMapItem] = []
    @Published var route: MKRoute?
    @Published var destination: MKMapItem?
    @Published var location: CLLocation?
    @Published var message: String?
    @Published var busy = false
    @Published var navigating = false
    @Published var guidance = "Where are we heading?"
    @Published var maneuverDistance = 0.0
    @Published var remainingDistance = 0.0
    @Published var remainingTime = 0.0
    @Published var gpsReady = false
    @Published var arrived = false
    @Published var nearby: [RoadAlert] = []
    @Published var upcomingAlert: RoadAlert?
    @Published var feedStatus = "Traffic has not refreshed yet"
    @Published var feedUpdated: Date?
    @Published var cameraStatus = "Camera database unavailable"
    @Published var mapRevision = UUID()
    @Published var currentManeuver: Maneuver?
    @Published var favourites: [SavedPlace] = [] { didSet { save(favourites, key: "favourites") } }
    @Published var voice = true { didSet { UserDefaults.standard.set(voice, forKey: "voice"); if !voice { speech.stopSpeaking(at: .immediate) } } }
    @Published var enabledKinds = Set(AlertKind.allCases) { didSet { save(Array(enabledKinds), key: "enabledKinds"); refreshNearby() } }
    @Published var appearance = "system" { didSet { UserDefaults.standard.set(appearance, forKey: "appearance") } }
    @Published var localReports: [RoadAlert] = [] { didSet { save(localReports, key: "localReports") } }
    private var official: [String: [RoadAlert]] = [:]
    private var cameras: [RoadAlert] = []
    private var geometry = RouteGeometry([])
    private var maneuvers: [Maneuver] = []
    private var along = 0.0
    private var plannedOrigin: CLLocation?
    private var offRouteCount = 0
    private var lastReroute = Date.distantPast
    private var navigationGeneration = UUID()
    private var announced = Set<String>()
    private var lastAlertCheck = Date.distantPast
    private var refreshTask: Task<Void, Never>?
    private var lastRefresh = Date.distantPast
    private var watchdog: AnyCancellable?
    private let manager = CLLocationManager()
    private let speech = AVSpeechSynthesizer()
    private var search: MKLocalSearch?
    private var directions: MKDirections?
    private var requestID = UUID()

    var usableLocation: CLLocation? {
        guard let location, fix(location).usable(at: Date()) else { return nil }; return location
    }
    var speedKPH: Int? {
        guard let location = usableLocation, location.speed >= 0, location.speedAccuracy >= 0, location.speedAccuracy <= 3 else { return nil }
        return Int((location.speed * 3.6).rounded())
    }
    var distanceText: String { Self.distance(maneuverDistance) }
    static func distance(_ metres: Double) -> String {
        metres >= 1000 ? String(format: "%.1f km", metres / 1000) : "\(Int(max(0, metres) / 10) * 10) m"
    }
    var visibleAlerts: [RoadAlert] { nearby }
    func fix(_ location: CLLocation) -> PositionFix {
        PositionFix(point: GeoPoint(location.coordinate.latitude, location.coordinate.longitude), time: location.timestamp, accuracy: location.horizontalAccuracy, speed: location.speed)
    }
    override init() {
        super.init()
        let defaults = UserDefaults.standard
        voice = defaults.object(forKey: "voice") == nil ? true : defaults.bool(forKey: "voice")
        appearance = defaults.string(forKey: "appearance") ?? "system"
        favourites = read([SavedPlace].self, key: "favourites") ?? []
        localReports = (read([RoadAlert].self, key: "localReports") ?? []).filter { $0.expires > Date() }
        if let saved = read([AlertKind].self, key: "enabledKinds") { enabledKinds = Set(saved) }
        manager.delegate = self; manager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        manager.activityType = .automotiveNavigation; manager.distanceFilter = 5
        manager.pausesLocationUpdatesAutomatically = false
        if let url = Bundle.main.url(forResource: "cameras", withExtension: "json"),
           let data = try? Data(contentsOf: url), let bundle = try? JSONDecoder().decode(CameraBundle.self, from: data) {
            cameras = bundle.alerts(); cameraStatus = "\(cameras.count) mapped cameras · \(bundle.retrieved.prefix(10)) snapshot · incomplete coverage"
        }
        watchdog = Timer.publish(every: 2, on: .main, in: .common).autoconnect().sink { [weak self] _ in self?.housekeeping() }
        refreshNearby()
    }
    private func save<T: Encodable>(_ value: T, key: String) {
        if let data = try? JSONEncoder().encode(value) { UserDefaults.standard.set(data, forKey: key) }
    }
    private func read<T: Decodable>(_ type: T.Type, key: String) -> T? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(type, from: data)
    }
    func requestLocation() {
        switch manager.authorizationStatus {
        case .notDetermined: manager.requestWhenInUseAuthorization()
        case .authorizedAlways, .authorizedWhenInUse: manager.startUpdatingLocation()
        case .denied, .restricted: message = "Enable location for Abeam in iPhone Settings to plan and navigate from your position."
        @unknown default: message = "Location is unavailable."
        }
    }
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if manager.authorizationStatus == .authorizedWhenInUse || manager.authorizationStatus == .authorizedAlways { manager.startUpdatingLocation() }
        else if manager.authorizationStatus == .denied || manager.authorizationStatus == .restricted { stopNavigation(); location = nil; gpsReady = false }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let latest = locations.last, latest.horizontalAccuracy >= 0 else { return }
        if let previous = location, latest.timestamp <= previous.timestamp { return }
        location = latest; gpsReady = usableLocation != nil
        if navigating { updateGuidance(latest) }
        if Date().timeIntervalSince(lastAlertCheck) > 3 { lastAlertCheck = Date(); refreshNearby(); checkAlerts() }
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        gpsReady = false
        if navigating { guidance = "Waiting for a reliable GPS signal"; speech.stopSpeaking(at: .immediate) }
    }
    private func housekeeping() {
        gpsReady = usableLocation != nil
        if navigating && !gpsReady { guidance = "GPS signal lost — guidance paused"; upcomingAlert = nil; speech.stopSpeaking(at: .immediate) }
        if Date().timeIntervalSince(lastAlertCheck) > 10 { lastAlertCheck = Date(); refreshNearby() }
        if Date().timeIntervalSince(lastRefresh) > 120 && (navigating || UIApplication.shared.applicationState == .active) { refreshTraffic() }
    }
    func searchPlaces() async {
        let term = query.trimmingCharacters(in: .whitespacesAndNewlines); guard !term.isEmpty else { return }
        search?.cancel(); let id = UUID(); requestID = id; busy = true; message = nil; results = []
        defer { if requestID == id { busy = false } }
        let request = MKLocalSearch.Request(); request.naturalLanguageQuery = term
        request.region = MKCoordinateRegion(center: usableLocation?.coordinate ?? Self.sydney, span: .init(latitudeDelta: 0.5, longitudeDelta: 0.5))
        let operation = MKLocalSearch(request: request); search = operation
        do {
            let response = try await operation.start(); guard id == requestID else { return }; results = response.mapItems
            if results.isEmpty { message = "No destinations found. Try a suburb or full address." }
        } catch { if id == requestID { message = "Search failed. Check your connection and try again." } }
    }
    func plan(to item: MKMapItem, rerouting: Bool = false) async {
        guard let origin = usableLocation else { requestLocation(); message = "Waiting for accurate GPS. Tap the destination again once GPS is ready."; return }
        if !rerouting { stopNavigation(); arrived = false; route = nil; destination = nil }
        directions?.cancel(); let id = UUID(); requestID = id; let generation = navigationGeneration
        busy = true; message = nil; results = []
        defer { if id == requestID { busy = false } }
        let request = MKDirections.Request(); request.source = MKMapItem(placemark: MKPlacemark(coordinate: origin.coordinate)); request.destination = item; request.transportType = .automobile
        let operation = MKDirections(request: request); directions = operation
        do {
            let response = try await operation.calculate()
            guard id == requestID, !rerouting || (navigating && generation == navigationGeneration) else { return }
            guard let first = response.routes.first else { message = "No driving route was found."; return }
            route = first; destination = item; plannedOrigin = origin; geometry = RouteGeometry(first.polyline.geoPoints)
            var previous = 0.0
            maneuvers = first.steps.enumerated().compactMap { index, step in
                guard !step.instructions.isEmpty, let point = step.polyline.geoPoints.first,
                      let match = geometry.match(point, previous: nil) else { return nil }
                let position = max(previous, match.along); previous = position
                return Maneuver(id: index, instruction: step.instructions, along: position, coordinate: .init(latitude: point.lat, longitude: point.lon))
            }
            along = 0; offRouteCount = 0; announced.removeAll()
            remainingDistance = first.distance; remainingTime = first.expectedTravelTime; mapRevision = UUID()
            if rerouting { speak("Route updated"); updateGuidance(origin) } else { guidance = item.name ?? "Your route is ready" }
        } catch { if id == requestID { message = "Route unavailable. Check your connection and try again."; if rerouting { guidance = "Rerouting unavailable — check connection" } } }
    }
    func startNavigation() {
        guard route != nil, usableLocation != nil else { requestLocation(); message = "A route and reliable GPS are required to start."; return }
        if let origin = plannedOrigin, let here = usableLocation, here.distance(from: origin) > 100, let destination {
            Task { await plan(to: destination); if route != nil && message == nil { startNavigation() } }; return
        }
        navigationGeneration = UUID(); navigating = true; arrived = false; announced.removeAll()
        manager.allowsBackgroundLocationUpdates = true; manager.showsBackgroundLocationIndicator = true
        UIApplication.shared.isIdleTimerDisabled = true
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .voicePrompt, options: [.duckOthers, .interruptSpokenAudioAndMixWithOthers])
        speak("Starting navigation")
        if let current = usableLocation { updateGuidance(current) }
    }
    func stopNavigation() {
        navigationGeneration = UUID(); navigating = false; upcomingAlert = nil
        manager.allowsBackgroundLocationUpdates = false; UIApplication.shared.isIdleTimerDisabled = false
        speech.stopSpeaking(at: .immediate); try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }
    func clearRoute() {
        stopNavigation(); requestID = UUID(); directions?.cancel(); search?.cancel(); busy = false
        route = nil; destination = nil; results = []; currentManeuver = nil; arrived = false; guidance = "Where are we heading?"; mapRevision = UUID()
    }
    private func updateGuidance(_ current: CLLocation) {
        guard fix(current).usable(at: Date()), let route else { return }
        let point = fix(current).point
        let course = current.speed > 3 && current.courseAccuracy >= 0 && current.courseAccuracy < 35 ? current.course : nil
        guard let match = geometry.match(point, previous: along, course: course, window: 800) else { return }
        if match.away > max(55, current.horizontalAccuracy * 2) {
            offRouteCount += 1; guidance = "Checking your route…"
            if offRouteCount >= 3 && Date().timeIntervalSince(lastReroute) > 20 && !busy, let destination {
                lastReroute = Date(); guidance = "Rerouting…"; speak("Rerouting"); Task { await plan(to: destination, rerouting: true) }
            }; return
        }
        offRouteCount = 0; along = max(0, match.along)
        remainingDistance = max(0, geometry.length - along); remainingTime = route.expectedTravelTime * remainingDistance / max(1, geometry.length)
        if remainingDistance < 35, let destination,
           current.distance(from: CLLocation(latitude: destination.placemark.coordinate.latitude, longitude: destination.placemark.coordinate.longitude)) < 50 {
            stopNavigation(); arrived = true; guidance = "You’ve arrived"; remainingDistance = 0; remainingTime = 0; speak("You have arrived at your destination"); return
        }
        let next = maneuvers.first { $0.along > along + 12 } ?? maneuvers.last
        currentManeuver = next; guidance = next?.instruction ?? "Continue along the route"
        maneuverDistance = max(0, (next?.along ?? geometry.length) - along)
        if let next {
            let threshold = maneuverDistance < 60 ? 0 : maneuverDistance < 300 ? 1 : 2
            let key = "maneuver-\(next.id)-\(threshold)"
            if threshold < 2 && !announced.contains(key) {
                announced.insert(key); speak(threshold == 0 ? next.instruction : "In \(Self.distance(maneuverDistance)), \(next.instruction)")
            }
        }
    }
    private func speak(_ text: String) {
        guard voice else { return }; try? AVAudioSession.sharedInstance().setActive(true); speech.stopSpeaking(at: .immediate)
        let utterance = AVSpeechUtterance(string: text); utterance.voice = AVSpeechSynthesisVoice(language: "en-AU"); utterance.rate = 0.48; speech.speak(utterance)
    }
    func refreshTraffic() {
        guard refreshTask == nil else { return }; lastRefresh = Date(); feedStatus = "Refreshing NSW traffic…"
        refreshTask = Task { [weak self] in
            guard let self else { return }; var successes = 0
            for name in RoadData.feeds {
                do { self.official[name] = try await RoadData.load(name); successes += 1 }
                catch { self.official[name] = [] }
            }
            self.feedStatus = successes == RoadData.feeds.count ? "NSW traffic refreshed · other states not connected" : "\(successes)/\(RoadData.feeds.count) NSW feeds available · coverage limited"
            self.feedUpdated = successes > 0 ? Date() : nil; self.refreshNearby(); self.refreshTask = nil
        }
    }
    func refreshNearby() {
        let centre = location.map { fix($0).point } ?? GeoPoint(Self.sydney.latitude, Self.sydney.longitude)
        let all = cameras + official.values.flatMap { $0 } + localReports
        nearby = Array(all.filter { $0.expires > Date() && enabledKinds.contains($0.kind) && centre.distance(to: $0.point) < 50000 }.sorted { centre.distance(to: $0.point) < centre.distance(to: $1.point) }.prefix(160))
        if let active = upcomingAlert, active.expires <= Date() || !enabledKinds.contains(active.kind) { upcomingAlert = nil }
    }
    private func checkAlerts() {
        guard navigating, usableLocation != nil, offRouteCount == 0 else { upcomingAlert = nil; return }
        let candidate = nearby.compactMap { alert -> (RoadAlert, Double)? in
            guard let match = geometry.match(alert.point, previous: along, window: 1200), match.away < 35, match.along > along, match.along - along < 600 else { return nil }
            return (alert, match.along - along)
        }.min { $0.1 < $1.1 }
        upcomingAlert = candidate?.0
        if let (alert, distance) = candidate, !announced.contains(alert.id), !speech.isSpeaking {
            announced.insert(alert.id); speak("\(alert.kind.rawValue) mapped nearby in \(Self.distance(distance)). Check road signs.")
        }
    }
    func addReport(_ kind: AlertKind) {
        guard let here = usableLocation else { message = "Reliable GPS is required to save a report."; requestLocation(); return }; let now = Date()
        localReports.insert(RoadAlert(id: UUID().uuidString, kind: kind, latitude: here.coordinate.latitude, longitude: here.coordinate.longitude,
                                     title: kind.rawValue, detail: "Your observation. Saved on this phone only; not independently verified or shared.", source: "Your report · this device", observed: now, expires: now.addingTimeInterval(kind == .police || kind == .mobile ? 1800 : 3600), isLocal: true), at: 0)
        refreshNearby(); message = "Report saved on this phone. It has not been shared with other drivers."
    }
    func removeReport(_ id: String) { localReports.removeAll { $0.id == id }; refreshNearby() }
    func saveDestination() {
        guard let destination else { return }; let coordinate = destination.placemark.coordinate
        if favourites.contains(where: { abs($0.latitude - coordinate.latitude) < 0.00001 && abs($0.longitude - coordinate.longitude) < 0.00001 }) { return }
        favourites.append(SavedPlace(name: destination.name ?? "Saved place", latitude: coordinate.latitude, longitude: coordinate.longitude))
    }
    func openAppleMaps() { destination?.openInMaps(launchOptions: [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving]) }
}
extension MKPolyline {
    var geoPoints: [GeoPoint] {
        var coordinates = [CLLocationCoordinate2D](repeating: .init(), count: pointCount)
        getCoordinates(&coordinates, range: NSRange(location: 0, length: pointCount))
        return coordinates.map { GeoPoint($0.latitude, $0.longitude) }
    }
}
