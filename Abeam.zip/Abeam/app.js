'use strict';
const $ = id => document.getElementById(id);
const kinds = {
  speed: {name:'Speed camera', icon:'▣', detail:'Fixed camera · sample location',distance:'300 m', colour:'#f5d48e'},
  police: {name:'Police reported',icon:'★',detail:'Community report · unverified demo',distance:'850 m',colour:'#abd2fc'},
  average: {name:'Average-speed zone',icon:'↔',detail:'Section start & end · sample zone',distance:'1.4 km',colour:'#c8b6f9'},
  works: {name:'Roadworks',icon:'△',detail:'Left lane closed · sample works',distance:'2.1 km',colour:'#ffbb81'},
  crash: {name:'Crash',icon:'!',detail:'Traffic slowing · sample incident',distance:'2.8 km',colour:'#efb0ad'},
  closure: {name:'Road closure',icon:'⊘',detail:'Sample closure',distance:'Nearby',colour:'#efb0ad'},
  hazard: {name:'Road hazard',icon:'◇',detail:'Sample hazard',distance:'Nearby',colour:'#f5d48e'},
  mobile: {name:'Mobile camera',icon:'▣',detail:'Community report · unverified demo',distance:'Nearby',colour:'#f5d48e'},
  redlight: {name:'Red-light camera',icon:'⋮',detail:'Sample camera',distance:'Nearby',colour:'#f5d48e'}
};
const enabled=new Set(Object.keys(kinds));
let reports=['speed','police','average','works','crash'].map(kind=>({kind,local:false}));
let selected='speed', timer=null, progress=0, voice=false, toastTimer, lastStage=-1;
function toast(text){$('toast').textContent=text;$('toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('visible'),3300);}
function openModal(title,html){$('modalTitle').textContent=title;$('modalBody').innerHTML=html;$('modal').showModal();}
$('close').onclick=()=>$('modal').close();
$('modal').addEventListener('click',e=>{if(e.target===$('modal')){const r=$('modal').getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)$('modal').close();}});
function render(){
  const visible=reports.filter(r=>enabled.has(r.kind));
  $('count').textContent=visible.length+' alerts';
  $('events').innerHTML=visible.length?visible.map((r)=>{const k=kinds[r.kind];return `<li><button class="event" data-detail="${r.kind}"><span class="eventicon" style="color:${k.colour}">${k.icon}</span><span><strong>${k.name}</strong><small>${r.local?'Your sample report · this session':k.detail}</small></span><span class="km">${r.local?'Here':k.distance}</span></button></li>`;}).join(''):'<li class="summarytext">All alerts are hidden. Change your alert preferences to see them again.</li>';
  document.querySelectorAll('.marker').forEach(m=>{m.style.display=enabled.has(m.dataset.kind)?'':'none';});
  document.querySelectorAll('[data-detail]').forEach(b=>b.onclick=()=>detail(b.dataset.detail));
  if(!enabled.has(selected)){selected=visible[0]?.kind||'speed';}
  $('notice').style.display=visible.length?'flex':'none';
  if(!visible.length)$('average').classList.remove('show');
  if(visible.length)showNotice(selected);
}
function showNotice(kind){selected=kind;const k=kinds[kind];$('noticeIcon').textContent=k.icon;$('noticeTitle').textContent=kind==='speed'?'Speed camera ahead':k.name;$('noticeMeta').textContent=k.detail;$('noticeDistance').textContent=k.distance;$('noticeDistance').style.color=k.colour;$('average').classList.toggle('show',kind==='average'&&enabled.has(kind));}
function detail(kind){
  const k=kinds[kind];showNotice(kind);
  openModal(k.name,`<p>${k.detail}. Fictional demonstration data, not a current road report.</p><div class="detail-line"><span>Distance in demo</span><strong>${k.distance}</strong></div><div class="detail-line"><span>Source</span><strong>Built-in sample</strong></div><div class="detail-line"><span>Live verification</span><strong>Not connected</strong></div>${kind==='average'?'<p style="margin-top:16px">The production app needs verified zone boundaries, direction and a continuous GPS track. The 54 km/h value here is simulated.</p>':''}<button class="modalbutton" id="dismissDetail">Back to map</button>`);
  $('dismissDetail').onclick=()=>$('modal').close();
}
$('notice').onclick=()=>detail(selected);
// Non-interactive map symbols have equivalent accessible buttons in the alert list.
document.querySelectorAll('.marker').forEach(m=>m.onclick=()=>detail(m.dataset.kind));
function mode(phone){$('device').classList.toggle('phone',phone);$('phoneMode').setAttribute('aria-pressed',String(phone));$('carMode').setAttribute('aria-pressed',String(!phone));}
$('phoneMode').onclick=()=>mode(true);$('carMode').onclick=()=>mode(false);
$('theme').onclick=()=>{const light=$('device').classList.toggle('light');$('theme').textContent=light?'☾':'☼';$('theme').setAttribute('aria-label',light?'Switch to night map':'Switch to daytime map');};
$('sound').onclick=()=>{if(!('speechSynthesis'in window)){toast('Speech playback is unavailable in this browser.');return;}voice=!voice;$('sound').setAttribute('aria-pressed',String(voice));$('sound').setAttribute('aria-label',voice?'Mute spoken demo alerts':'Enable spoken demo alerts');$('sound').textContent=voice?'♫':'♪';if(!voice)speechSynthesis.cancel();toast(voice?'Spoken demo alerts on':'Spoken demo alerts off');};
function speak(text){if(voice&&'speechSynthesis'in window){speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang='en-AU';speechSynthesis.speak(u);}}
function pause(){clearInterval(timer);timer=null;$('play').innerHTML=progress?'▶ &nbsp; Resume demo drive':'▶ &nbsp; Play demo drive';}
function reset(){pause();progress=0;lastStage=-1;$('car').setAttribute('transform','translate(543 497) rotate(-20)');$('turnDistance').textContent='450 m';$('turnName').textContent='Oxford Street';$('etaTime').textContent='12 min';$('etaSub').textContent='9:53 arrival · 6.4 km';$('end').textContent='End demo';$('play').innerHTML='▶ &nbsp; Play demo drive';showNotice(enabled.has('speed')?'speed':([...enabled][0]||'speed'));render();}
function tick(){
  progress=Math.min(progress+.004,1);const path=$('routePath'),length=path.getTotalLength();const offset=length*(.17+progress*.83);const point=path.getPointAtLength(offset);const next=path.getPointAtLength(Math.min(offset+2,length));const angle=Math.atan2(next.x-point.x,-(next.y-point.y))*180/Math.PI;
  $('car').setAttribute('transform',`translate(${point.x} ${point.y}) rotate(${angle})`);
  const stage=progress<.35?0:progress<.66?1:2;
  $('turnDistance').textContent=Math.max(30,Math.round((1-progress)*450/10)*10)+' m';$('etaTime').textContent=Math.max(1,Math.ceil(12*(1-progress)))+' min';$('etaSub').textContent='Demo arrival · '+Math.max(.1,6.4*(1-progress)).toFixed(1)+' km';
  if(stage!==lastStage){lastStage=stage;const kind=['speed','police','average'][stage];if(enabled.has(kind)){showNotice(kind);speak('Demo. '+kinds[kind].name+' ahead.');}if(stage===2)$('turnName').textContent='Average-speed zone';}
  if(progress===1){pause();$('etaTime').textContent='Arrived';$('etaSub').textContent='Demo complete';$('play').innerHTML='↻ &nbsp; Replay demo';toast('Demo complete. No live GPS or road reports were used.');}
}
$('play').onclick=()=>{if(timer){pause();return;}if(progress>=1)reset();timer=setInterval(tick,100);$('play').innerHTML='Ⅱ &nbsp; Pause demo drive';};
$('recenter').onclick=()=>{reset();toast('Demo drive reset');};
$('end').onclick=()=>{reset();toast('Demo ended. Ready for another preview.');};
$('filters').onclick=()=>{openModal('Your heads-up, your way',`<p>Choose what appears in this preview.</p>${Object.entries(kinds).map(([key,k])=>`<label class="filterrow">${k.name}<input type="checkbox" value="${key}" ${enabled.has(key)?'checked':''}></label>`).join('')}<button id="saveFilters" class="modalbutton">Save preferences</button>`);$('saveFilters').onclick=()=>{enabled.clear();$('modalBody').querySelectorAll('input:checked').forEach(i=>enabled.add(i.value));$('modal').close();render();toast('Preview alert preferences updated');};};
$('report').onclick=()=>{openModal('What’s on the road?',`<p>Demo only. Reports stay in this browser session and are not shared with other drivers.</p><div class="grid">${Object.entries(kinds).map(([key,k])=>`<button class="choice" data-report="${key}"><span>${k.icon}</span>${k.name}</button>`).join('')}</div>`);document.querySelectorAll('[data-report]').forEach(b=>b.onclick=()=>{const kind=b.dataset.report;reports.unshift({kind,local:true});enabled.add(kind);$('modal').close();render();showNotice(kind);toast('Sample report added locally — nothing was published');});};
document.addEventListener('visibilitychange',()=>{if(document.hidden){pause();if('speechSynthesis'in window)speechSynthesis.cancel();}});
render();if(window.innerWidth<530)mode(true);
