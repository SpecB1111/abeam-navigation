// swift-tools-version: 5.9
import PackageDescription
let package = Package(name: "AbeamCore", products: [.library(name: "AbeamCore", targets: ["AbeamCore"])], targets: [
    .target(name: "AbeamCore", path: "Core"),
    .testTarget(name: "AbeamCoreTests", dependencies: ["AbeamCore"], path: "Tests/AbeamCoreTests")
])
