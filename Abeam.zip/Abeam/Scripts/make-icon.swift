import AppKit
let size = NSSize(width: 1024, height: 1024)
let image = NSImage(size: size)
image.lockFocus()
NSColor(calibratedRed: 0.055, green: 0.10, blue: 0.13, alpha: 1).setFill()
NSBezierPath(rect: NSRect(origin: .zero, size: size)).fill()
NSColor(calibratedRed: 0.59, green: 0.95, blue: 0.79, alpha: 1).setFill()
NSBezierPath(roundedRect: NSRect(x: 178, y: 178, width: 668, height: 668), xRadius: 195, yRadius: 195).fill()
NSColor(calibratedRed: 0.045, green: 0.18, blue: 0.14, alpha: 1).setStroke()
let arrow = NSBezierPath(); arrow.lineWidth = 68; arrow.lineCapStyle = .round; arrow.lineJoinStyle = .round
arrow.move(to: NSPoint(x: 365, y: 351)); arrow.line(to: NSPoint(x: 655, y: 641))
arrow.move(to: NSPoint(x: 440, y: 641)); arrow.line(to: NSPoint(x: 655, y: 641)); arrow.line(to: NSPoint(x: 655, y: 426)); arrow.stroke()
image.unlockFocus()
let rep = NSBitmapImageRep(data: image.tiffRepresentation!)!
let folder = URL(fileURLWithPath: "ios/Resources/Assets.xcassets/AppIcon.appiconset", isDirectory: true)
try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
try rep.representation(using: .png, properties: [:])!.write(to: folder.appendingPathComponent("AppIcon.png"))
try "{\"images\":[{\"filename\":\"AppIcon.png\",\"idiom\":\"universal\",\"platform\":\"ios\",\"size\":\"1024x1024\"}],\"info\":{\"author\":\"xcode\",\"version\":1}}".write(to: folder.appendingPathComponent("Contents.json"), atomically: true, encoding: .utf8)
