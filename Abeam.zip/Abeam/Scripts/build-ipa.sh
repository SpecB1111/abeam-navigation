#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
swift Scripts/make-icon.swift
xcodegen generate --spec ios/project.yml
xcodebuild -project ios/Abeam.xcodeproj -scheme Abeam -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/device \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY= build
app="$PWD/build/device/Build/Products/Release-iphoneos/Abeam.app"
test -f "$app/Abeam"
staging="$(mktemp -d "${TMPDIR:-/tmp}/abeam-package.XXXXXX")"
mkdir -p "$staging/Payload"
ditto "$app" "$staging/Payload/Abeam.app"
ditto -c -k --keepParent "$staging/Payload" "$PWD/build/Abeam.ipa"
unzip -t build/Abeam.ipa
# Also compile the CarPlay integration. It cannot run without Apple's entitlement.
xcodebuild -project ios/Abeam.xcodeproj -scheme AbeamCarPlay -configuration Debug \
  -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' -derivedDataPath build/carplay \
  CODE_SIGNING_ALLOWED=NO build
