#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
device=$(xcrun simctl list devices available -j | python3 -c 'import sys,json; d=json.load(sys.stdin); print(next(x["udid"] for group in d["devices"].values() for x in group if x["name"].startswith("iPhone")))')
xcodebuild -project ios/Abeam.xcodeproj -scheme Abeam -configuration Debug \
  -destination "platform=iOS Simulator,id=$device" -derivedDataPath build/ui \
  -resultBundlePath build/AbeamUI.xcresult CODE_SIGNING_ALLOWED=NO test
xcrun simctl launch "$device" au.specb1111.abeam -navigationNoticeAccepted YES
sleep 5
xcrun simctl io "$device" screenshot build/Abeam-iPhone.png
